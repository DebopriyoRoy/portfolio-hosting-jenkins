<?php

$name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];

require "vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

$mail = new PHPMailer(true);

//$mail->SMTPDebug = SMTP::DEBUG_SERVER;

try {
    // SMTP config
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'debopriyo.ca@gmail.com';
    $mail->Password   = 'jyrn ssmo djiy goie';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Visitor info
    $fromEmail = $_POST['email'];
    $fromName  = $_POST['name'];

    // IMPORTANT: Use your authenticated email as sender
    $mail->setFrom('debopriyo.ca@gmail.com', 'Contact Form - Your Website');

    // Reply-To (visitor's email) - this allows you to reply directly to the visitor
    $mail->addReplyTo($fromEmail, $fromName);

    // Recipient (your inbox)
    $mail->addAddress('debopriyo.inbox@gmail.com', 'Debopriyo');

    // Email content optimized for primary inbox
    $mail->isHTML(true);
    
    // Clean, personal subject line
    $mail->Subject = "New Contact: " . $_POST['subject'];
    
    // Professional HTML email body
    $mail->Body = '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px;">New Contact Form Submission</h2>
        
        <div style="background-color: #f9f9f9; padding: 20px; border-radius: 5px; margin: 20px 0;">
            <p><strong>Name:</strong> ' . htmlspecialchars($fromName) . '</p>
            <p><strong>Email:</strong> ' . htmlspecialchars($fromEmail) . '</p>
            <p><strong>Subject:</strong> ' . htmlspecialchars($_POST['subject']) . '</p>
        </div>
        
        <div style="margin: 20px 0;">
            <h3 style="color: #333;">Message:</h3>
            <div style="background-color: #fff; padding: 15px; border-left: 4px solid #4CAF50; margin: 10px 0;">
                ' . nl2br(htmlspecialchars($_POST['message'])) . '
            </div>
        </div>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666;">
            <p>This email was sent from your website contact form.</p>
            <p>Received on: ' . date('F j, Y \a\t g:i A') . '</p>
        </div>
    </div>';
    
    // Plain text version for better deliverability
    $mail->AltBody = "New Contact Form Submission\n\n" .
                     "Name: " . $fromName . "\n" .
                     "Email: " . $fromEmail . "\n" .
                     "Subject: " . $_POST['subject'] . "\n\n" .
                     "Message:\n" . $_POST['message'] . "\n\n" .
                     "Received on: " . date('F j, Y \a\t g:i A');

    // Additional headers to improve inbox placement
    $mail->addCustomHeader('X-Mailer', 'Website Contact Form');
    $mail->addCustomHeader('X-Priority', '3'); // Normal priority
    $mail->addCustomHeader('Importance', 'Normal');
    $mail->addCustomHeader('X-MSMail-Priority', 'Normal');
    
    // Set message type to ensure it's treated as transactional
    $mail->addCustomHeader('List-Unsubscribe', '<mailto:noreply@' . $_SERVER['HTTP_HOST'] . '>');
    $mail->addCustomHeader('Precedence', 'bulk');

    $mail->send();

    header("Location: sent.html");
    exit();

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>